<?php
$servername = "localhost";
$database = "tsa_web";
$username = "root";
$password = "";

$connect = new mysqli($servername, $username, $password, $database);
