<?php
class User
{
    public function getAllUsers()
    {
        return [
            ['id' => 1, 'name' => 'dina'],
            ['id' => 2, 'name' => 'dino'],
            ['id' => 3, 'name' => 'dini'],
        ];
    }
}
