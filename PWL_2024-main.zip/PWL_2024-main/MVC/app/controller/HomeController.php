<?php

class Homecontroller
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function index()
    {
        $users =  $this->userModel->getAllUsers();
        require '../app/views/home/php';
    }
}
