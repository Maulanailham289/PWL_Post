<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PenjualanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            ['user_id' => 1, 'pembeli' => 'Alice Johnson', 'penjualan_kode' => 'PJ001', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 2, 'pembeli' => 'Bob Smith', 'penjualan_kode' => 'PJ002', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 3, 'pembeli' => 'Charlie Brown', 'penjualan_kode' => 'PJ003', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 1, 'pembeli' => 'Diana Prince', 'penjualan_kode' => 'PJ004', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 2, 'pembeli' => 'Edward Norton', 'penjualan_kode' => 'PJ005', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 3, 'pembeli' => 'Fiona Apple', 'penjualan_kode' => 'PJ006', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 1, 'pembeli' => 'George Clooney', 'penjualan_kode' => 'PJ007', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 2, 'pembeli' => 'Hannah Simone', 'penjualan_kode' => 'PJ008', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 3, 'pembeli' => 'Irene Adler', 'penjualan_kode' => 'PJ009', 'penjualan_tanggal' => Carbon::now()],
            ['user_id' => 1, 'pembeli' => 'Jack Sparrow', 'penjualan_kode' => 'PJ010', 'penjualan_tanggal' => Carbon::now()],
        ];

        DB::table('t_penjualan')->insert($data);
    }
}
