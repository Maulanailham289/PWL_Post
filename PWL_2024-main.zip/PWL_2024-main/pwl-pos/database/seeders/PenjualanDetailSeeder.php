<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PenjualanDetailSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $data = [
            // Transaksi 1
            ['penjualan_id' => 1, 'barang_id' => 1, 'harga' => 15000, 'jumlah' => 1],
            ['penjualan_id' => 1, 'barang_id' => 2, 'harga' => 25000, 'jumlah' => 2],
            ['penjualan_id' => 1, 'barang_id' => 3, 'harga' => 35000, 'jumlah' => 3],
            // Transaksi 2
            ['penjualan_id' => 2, 'barang_id' => 4, 'harga' => 45000, 'jumlah' => 4],
            ['penjualan_id' => 2, 'barang_id' => 5, 'harga' => 55000, 'jumlah' => 5],
            ['penjualan_id' => 2, 'barang_id' => 6, 'harga' => 65000, 'jumlah' => 6],
            // Transaksi 3
            ['penjualan_id' => 3, 'barang_id' => 7, 'harga' => 75000, 'jumlah' => 7],
            ['penjualan_id' => 3, 'barang_id' => 8, 'harga' => 85000, 'jumlah' => 8],
            ['penjualan_id' => 3, 'barang_id' => 9, 'harga' => 95000, 'jumlah' => 9],
            // Transaksi 4
            ['penjualan_id' => 4, 'barang_id' => 10, 'harga' => 105000, 'jumlah' => 10],
            ['penjualan_id' => 4, 'barang_id' => 1, 'harga' => 15000, 'jumlah' => 11],
            ['penjualan_id' => 4, 'barang_id' => 2, 'harga' => 25000, 'jumlah' => 12],
            // Transaksi 5
            ['penjualan_id' => 5, 'barang_id' => 3, 'harga' => 35000, 'jumlah' => 13],
            ['penjualan_id' => 5, 'barang_id' => 4, 'harga' => 45000, 'jumlah' => 14],
            ['penjualan_id' => 5, 'barang_id' => 5, 'harga' => 55000, 'jumlah' => 15],
            // Transaksi 6
            ['penjualan_id' => 6, 'barang_id' => 6, 'harga' => 65000, 'jumlah' => 16],
            ['penjualan_id' => 6, 'barang_id' => 7, 'harga' => 75000, 'jumlah' => 17],
            ['penjualan_id' => 6, 'barang_id' => 8, 'harga' => 85000, 'jumlah' => 18],
            // Transaksi 7
            ['penjualan_id' => 7, 'barang_id' => 9, 'harga' => 05000, 'jumlah' => 19],
            ['penjualan_id' => 7, 'barang_id' => 10, 'harga' => 105000, 'jumlah' => 20],
            ['penjualan_id' => 7, 'barang_id' => 1, 'harga' => 15000, 'jumlah' => 21],
            // Transaksi 8
            ['penjualan_id' => 8, 'barang_id' => 2, 'harga' => 25000, 'jumlah' => 22],
            ['penjualan_id' => 8, 'barang_id' => 3, 'harga' => 35000, 'jumlah' => 23],
            ['penjualan_id' => 8, 'barang_id' => 4, 'harga' => 45000, 'jumlah' => 24],
            // Transaksi 9
            ['penjualan_id' => 9, 'barang_id' => 5, 'harga' => 55000, 'jumlah' => 25],
            ['penjualan_id' => 9, 'barang_id' => 6, 'harga' => 65000, 'jumlah' => 26],
            ['penjualan_id' => 9, 'barang_id' => 7, 'harga' => 75000, 'jumlah' => 27],
            // Transaksi 10
            ['penjualan_id' => 10, 'barang_id' => 8, 'harga' => 85000, 'jumlah' => 28],
            ['penjualan_id' => 10, 'barang_id' => 9, 'harga' => 95000, 'jumlah' => 29],
            ['penjualan_id' => 10, 'barang_id' => 10, 'harga' => 105000, 'jumlah' => 30],
        ];

        DB::table('t_penjualan_detail')->insert($data);
    }
}
