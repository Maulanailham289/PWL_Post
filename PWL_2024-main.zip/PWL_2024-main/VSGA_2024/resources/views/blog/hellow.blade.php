<html>
<body>
    <h1>Hello, {{ $name }}</h1>
    <h1>You are {{ $pekerjaan }}</h1>
</body>
</html>
