<a href="{{ route('about') }}">About Us</a>
<p>ini halaman about</p>
