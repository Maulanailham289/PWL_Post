<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VSGA</title>
</head>

<body>
    <h2>ini adalah percobaan</h2>
    <h3>semangat belajar</h3>
</body>

</html>
