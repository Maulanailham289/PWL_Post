<a href="{{ route('about') }}">About Us</a>
<p>ini halaman tampil</p>
