<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PengajarController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\CRUDController;
use App\Http\Controllers\CRUDPhoto;
use App\Http\Controllers\WelcomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return ('Selamat Datang');
});
Route::get('/hello', function () {
    return 'Hello VSGA';
});
Route::get('/word', function () {
    return 'hello Dunia';
});
Route::get('/about', function () {
    return 'NIM : 2141762012';
});
// Percobaan 2: Basic Parameter
Route::get('/user/{name}', function ($name) {
    return 'Nama saya ' . $name;
});
Route::get('/posts/{post}/{comment}', function ($post, $comment) {
    return 'Pos ke-' . $post . " Komentar ke-: " . $comment;
});
// Percobaan 3: Optional Parameter
Route::get('/user {name?}', function ($name = null) {
    return 'Nama saya' . $name;
});
Route::get('/kodebarang/(jenis?}/{merek?}', function ($jk = 'k01', $mrk = 'nokia') {
    return "kode barang $jk dan nama barang $mrk";
});
// Percobaan 4: Route name
Route::get('about', function () {
    return view('about');
})->name('about');
Route::get('tampil', function () {
    return view('tampil');
})->name('tampil');
// Percobaan 5: Route Redirect,Route Group
Route::get('/pesandisini', function () {
    return '<h1> pesan disini </h1>';
});
Route::redirect('/contact-us', '/pesandisini');
Route::get('/polinema/dosen', function () {
    return "‹h1 > daftar nama dosen </h1›";
});
Route::get('/polinema/tendik', function () {
    return "‹h1 > daftar nama tendik </h1›";
});
Route::get('/polinema/jurusan', function () {
    return "‹h1 › daftar nama jurusan </h1>";
});
// Route Group
Route::prefix('/admin')->group(function () {
    Route::get('/dosen', function () {
        echo "‹h1>Daftar dosen</h1>";
    });
    Route::get('/tendik', function () {
        echo "<h1>Daftar tendik</h1›";
    });
    Route::get('/jurusan', function () {
        echo "<h1>Daftar jurusan</h1>";
    });
});
// Percobaan 6: Route Fallback
Route::fallback(function () {
    return "Maaf, alamt ini tidak ditemukan";
});
// Percobaan 7: Penggunaan Route untuk Controller
Route::get('/daftar-dosen', [pengajarController::class, 'daftarPengajar']);
Route::get('/tabel-pengajar', [pengajarController::class, 'tabelPengajar']);
Route::get('/blog-pengajar', [pengajarController::class, 'blogPengajar']);
// Percobaan 8: Mengakses View dari Controller
Route::get('pasar-buah', [PageController::class, 'satu']);
// Percobaan 9: Resource Controller
Route::resource('crud', CRUDController::class);
Route::resource('photos', CRUDPhoto::class)->only([
    'index',
    'show'
]);
Route::resource('photos', CRUDPhoto::class)->except([
    'create',
    'store',
    'update',
    'destroy'
]);
// Percobaan 10: Membuat View
Route::get('/selamat', function () {
    return view('hello', ['name' => 'dino']);
});
// Percobaan 11: Membuat View dari controller
Route::get('/greeting', [
    WelcomeController::class,
    'greeting'
]);
